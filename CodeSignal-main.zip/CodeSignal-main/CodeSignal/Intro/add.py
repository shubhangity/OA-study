# Write a function that returns the sum of two numbers.

def solution(param1, param2):
    return param1 + param2